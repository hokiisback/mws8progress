import 'package:flutter/material.dart';
import 'package:flutter_app_praktik/pages/alamat.dart';
import 'package:flutter_app_praktik/pages/riwayat.dart';
import 'keranjang.dart'; // Import halaman keranjang

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
   final List<Map<String, dynamic>> items = [
    {
      'name': 'Taro',
      'price': 15000,
      'image': 'http://taro.id/content/taro/img/taro-net-potato-bbq.jpg'
    },
    {
      'name': 'Kusuka',
      'price': 20000,
      'image':
          'https://tastysnack.id/cdn/shop/files/kusukapedas_300x.png?v=1704188186g'
    },
    {
      'name': 'Nabati',
      'price': 25000,
      'image':
          'https://ik.imagekit.io/dcjlghyytp1/fe984c31419c7a5a7884e14631610325?tr=f-auto,w-360'
    },
    {
      'name': 'Aqua',
      'price': 5000,
      'image':
          'https://images.tokopedia.net/img/cache/900/product-1/2018/4/28/2642564/2642564_8fff405b-851f-4196-b943-acae3d697e63_800_800.jpg'
    },
    {
      'name': 'FreshTea',
      'price': 30000,
      'image':
          'https://images.tokopedia.net/img/cache/900/VqbcmM/2022/7/2/68e3e292-3bd7-4455-963e-a2b302acd2aa.png'
    },
    {
      'name': 'FruitTea',
      'price': 35000,
      'image':
          'https://images.tokopedia.net/img/cache/900/hDjmkQ/2024/2/23/29009021-17dc-45f1-89b1-342947aee62e.jpg'
    },
  ];


  List<Map<String, dynamic>> cartItems = []; // List untuk item yang ditambahkan ke keranjang

  void addToCart(Map<String, dynamic> item) {
    setState(() {
      cartItems.add(item); // Menambahkan item ke keranjang
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('${item['name']} ditambahkan ke keranjang')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('HOME'),
        backgroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            SizedBox(
              width: double.infinity,
              height: 150,
              child: Center(
                child: Image.network(
                    'https://www.shutterstock.com/shutterstock/photos/2429785869/display_1500/stock-photo-sragen-indonesia-february-view-of-grocery-traders-in-local-shop-or-called-kiosk-that-2429785869.jpg'),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const JamPage()),
                    );
                  },
                  child:
                      const Icon(Icons.access_time, color: Colors.purple, size: 32),
                ),
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => KeranjangPage(cartItems: cartItems)),
                    );
                  },
                  child:
                      const Icon(Icons.shopping_cart, color: Colors.purple, size: 32),
                ),
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const GedungPage()),
                    );
                  },
                  child:
                      const Icon(Icons.location_city, color: Colors.purple, size: 32),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Expanded(
              child: ListView.builder(
                itemCount: items.length,
                itemBuilder: (context, index) {
                  final item = items[index];
                  return ListTile(
                    leading: Image.network(
                      item['image'], // Menampilkan gambar barang
                      width: 50,
                      height: 50,
                      fit: BoxFit.cover,
                    ),
                    title: Text(item['name']),
                    subtitle: Text('Rp ${item['price']}'),
                    trailing: IconButton(
                      icon: const Icon(Icons.add_shopping_cart, color: Colors.purple),
                      onPressed: () {
                        addToCart(item); // Tambahkan item ke keranjang
                      },
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
