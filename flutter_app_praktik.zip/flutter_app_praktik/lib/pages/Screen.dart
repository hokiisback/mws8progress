import 'package:flutter/material.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center, // Rata tengah
          children: [
            // Gambar Profil
            const CircleAvatar(
              radius: 50,
              backgroundImage: NetworkImage(
                'https://cdn3.pixelcut.app/1/3/profile_picture_1728ecf2bd.jpg',
              ),
            ),
            const SizedBox(height: 16),
            // Nama Pengguna
            const Text(
              'Majid Armansyah',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            // Deskripsi
            Text(
              'Mobile and Web Developer | Tech Enthusiast',
              style: TextStyle(
                fontSize: 16,
                color: Colors.grey[600],
              ),
            ),
            const SizedBox(height: 24),
            // Tombol Edit Profil
            ElevatedButton(
              onPressed: () {
                // Tambahkan aksi edit profil di sini
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.purple,
                padding:
                    const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              ),
              child: const Text(
                'Edit Profile',
                style: TextStyle(
                  fontSize: 16,
                  color: Color.fromARGB(255, 255, 255, 255),
                ),
              ),
            ),
            const SizedBox(height: 24),
            // Info Tambahan
            const Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'About Me',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Lorem ipsum dolor sit amet, consectetur adipiscing elit. '
              'Vivamus lacinia odio vitae vestibulum. Cras vitae urna a justo ultrices tincidunt.',
              style: TextStyle(fontSize: 16),
              textAlign: TextAlign.justify, // Rata kiri dan kanan
            ),
          ],
        ),
      ),
    );
  }
}
