import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class GedungPage extends StatelessWidget {
  final String gedungName = 'Gedung Utama';
  final String gedungDescription =
      'Gedung ini adalah pusat kegiatan dan layanan bagi pengunjung. Terdapat berbagai fasilitas modern dan ruang multifungsi untuk mendukung berbagai acara.';
  final String gedungImage =
      'https://example.com/gedung.jpg'; // Ganti dengan URL gambar yang valid

  // URL Google Maps (ganti dengan URL lokasi gedung yang sebenarnya)
  final String gmapsUrl = 'https://maps.app.goo.gl/UcKCLwmCgJQwaLHS6';

  const GedungPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Gedung',
          style: TextStyle(
            color: Color.fromARGB(255, 255, 255, 255),
          ),
        ),
        backgroundColor: Colors.deepPurple,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Gambar Gedung
            ClipRRect(
              borderRadius: BorderRadius.circular(12.0),
              child: Image.network(
                gedungImage,
                width: double.infinity,
                height: 200,
                fit: BoxFit.cover,
              ),
            ),
            const SizedBox(height: 16),

            // Nama Gedung
            Text(
              gedungName,
              style: const TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                color: Colors.deepPurple,
              ),
            ),
            const SizedBox(height: 8),

            // Deskripsi Gedung
            Text(
              gedungDescription,
              style: const TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 16),

            // Button untuk membuka Google Maps
            ElevatedButton(
              onPressed: () async {
                // Mengarahkan ke Google Maps
                if (await canLaunch(gmapsUrl)) {
                  await launch(gmapsUrl);
                } else {
                  throw 'Could not launch $gmapsUrl';
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.deepPurple, // Warna tombol
              ),
              child: const Text(
                'Lihat di Google Maps',
                style: TextStyle(
                  color: Color.fromARGB(255, 255, 255, 255),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
