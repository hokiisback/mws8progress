import 'package:flutter/material.dart';
import 'dart:async';

class JamPage extends StatefulWidget {
  const JamPage({super.key});

  @override
  _JamPageState createState() => _JamPageState();
}

class _JamPageState extends State<JamPage> {
  String _currentTime = '';

  @override
  void initState() {
    super.initState();
    _updateTime();
    Timer.periodic(const Duration(seconds: 1), (Timer t) => _updateTime());
  }

  void _updateTime() {
    setState(() => _currentTime =
          DateTime.now().toLocal().toString().split(' ')[1].split('.')[0]);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Waktu',
          style: TextStyle(
            color: Color.fromARGB(255, 255, 255, 255),
          ),
        ),
        backgroundColor: Colors.deepPurple,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('Waktu Sekarang:', style: TextStyle(fontSize: 24)),
            Text(_currentTime, style: const TextStyle(fontSize: 48)),
          ],
        ),
      ),
    );
  }
}
